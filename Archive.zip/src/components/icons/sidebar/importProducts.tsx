import { MdSaveAlt } from "react-icons/md";

export const ImportProductsIcons: React.FC<React.SVGAttributes<{}>> = (props) => (
    <MdSaveAlt className="h-5 w-5 me-4" color='gray' />
  );
  